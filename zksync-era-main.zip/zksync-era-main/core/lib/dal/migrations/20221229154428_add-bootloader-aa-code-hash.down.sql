ALTER TABLE miniblocks DROP bootloader_code_hash;
ALTER TABLE miniblocks DROP default_aa_code_hash;
