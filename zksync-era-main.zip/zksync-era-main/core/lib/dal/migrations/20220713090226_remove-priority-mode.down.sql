ALTER TABLE blocks ADD COLUMN priority_ops_complexity NUMERIC(80) NOT NULL;
