ALTER TABLE transactions ADD COLUMN l1_block_number INT;
