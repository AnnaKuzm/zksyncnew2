ALTER TABLE blocks ADD COLUMN used_contract_hashes JSONB NOT NULL;

