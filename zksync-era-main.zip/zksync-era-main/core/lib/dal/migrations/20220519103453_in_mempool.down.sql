ALTER TABLE transactions DROP COLUMN IF EXISTS in_mempool;
