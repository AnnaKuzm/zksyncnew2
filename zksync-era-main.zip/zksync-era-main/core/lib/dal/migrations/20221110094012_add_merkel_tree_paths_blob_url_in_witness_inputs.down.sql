ALTER TABLE witness_inputs DROP COLUMN IF EXISTS merkel_tree_paths_blob_url;
