ALTER TABLE transactions DROP COLUMN mempool_preceding_nonce_gaps;
