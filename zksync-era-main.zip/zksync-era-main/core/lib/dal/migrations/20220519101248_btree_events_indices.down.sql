DROP INDEX IF EXISTS events_address_idx;
DROP INDEX IF EXISTS events_topic1_idx;
DROP INDEX IF EXISTS events_topic2_idx;
DROP INDEX IF EXISTS events_topic3_idx;
DROP INDEX IF EXISTS events_topic4_idx;
