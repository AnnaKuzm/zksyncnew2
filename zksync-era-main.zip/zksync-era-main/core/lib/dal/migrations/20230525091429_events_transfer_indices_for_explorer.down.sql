DROP INDEX IF EXISTS events_transfer_from;
DROP INDEX IF EXISTS events_transfer_to;
