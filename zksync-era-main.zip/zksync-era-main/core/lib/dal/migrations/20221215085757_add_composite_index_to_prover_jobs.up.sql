CREATE UNIQUE INDEX prover_jobs_composite_index ON prover_jobs(l1_batch_number, aggregation_round, sequence_number);
