ALTER TABLE blocks DROP COLUMN priority_ops_complexity;
