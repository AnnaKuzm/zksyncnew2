ALTER TABLE scheduler_witness_jobs DROP COLUMN IF EXISTS scheduler_witness_blob_url;
ALTER TABLE scheduler_witness_jobs DROP COLUMN IF EXISTS final_node_aggregations_blob_url;
