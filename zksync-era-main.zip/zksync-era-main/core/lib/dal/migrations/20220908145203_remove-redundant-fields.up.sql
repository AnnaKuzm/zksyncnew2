ALTER TABLE transactions DROP column type;
ALTER TABLE transactions DROP column fee_token;
