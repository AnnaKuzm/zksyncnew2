DROP INDEX blocks_hash;
