ALTER TABLE transactions DROP COLUMN execution_info;
