ALTER TABLE prover_jobs ADD COLUMN IF NOT EXISTS circuit_input_blob_url TEXT;
