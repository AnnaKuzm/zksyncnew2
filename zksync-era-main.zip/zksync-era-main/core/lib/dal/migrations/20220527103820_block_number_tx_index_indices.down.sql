DROP INDEX IF EXISTS transactions_block_number_tx_index;
DROP INDEX IF EXISTS events_block_number_tx_index;
