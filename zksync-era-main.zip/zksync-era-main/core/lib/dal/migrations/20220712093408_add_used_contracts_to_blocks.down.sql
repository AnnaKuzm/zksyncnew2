ALTER TABLE blocks DROP COLUMN used_contract_hashes;

