ALTER TABLE gpu_prover_queue
    DROP COLUMN IF EXISTS region;
