DROP index ix_prover_jobs_t1;
