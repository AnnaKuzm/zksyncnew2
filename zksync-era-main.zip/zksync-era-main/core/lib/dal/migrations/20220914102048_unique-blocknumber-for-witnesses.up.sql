ALTER TABLE witness_inputs ADD CONSTRAINT unique_witnesses UNIQUE (l1_batch_number);
