ALTER TABLE gpu_prover_queue ALTER COLUMN queue_capacity SET NOT NULL;
ALTER TABLE gpu_prover_queue ALTER COLUMN queue_free_slots SET NOT NULL;
