CREATE INDEX IF NOT EXISTS prover_jobs_circuit_type_and_status_index ON prover_jobs (circuit_type, status);
