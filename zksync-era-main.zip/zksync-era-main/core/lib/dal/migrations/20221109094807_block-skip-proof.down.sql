ALTER TABLE l1_batches DROP COLUMN skip_proof;
