ALTER TABLE l1_batches ADD COLUMN ergs_per_code_decommittment_word INT NOT NULL DEFAULT 0;
