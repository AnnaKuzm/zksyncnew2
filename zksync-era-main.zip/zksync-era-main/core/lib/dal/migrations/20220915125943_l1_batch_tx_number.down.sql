ALTER TABLE transactions DROP COLUMN l1_batch_tx_index;
