DROP INDEX events_address_idx;
DROP INDEX events_topic1_idx;
DROP INDEX events_topic2_idx;
DROP INDEX events_topic3_idx;
DROP INDEX events_topic4_idx;
