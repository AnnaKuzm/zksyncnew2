ALTER TABLE witness_inputs DROP COLUMN IF EXISTS time_taken;
