ALTER TABLE miniblocks ADD bootloader_code_hash BYTEA;
ALTER TABLE miniblocks ADD default_aa_code_hash BYTEA;
