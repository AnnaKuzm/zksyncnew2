DROP TABLE IF EXISTS storage_logs_dedup;
