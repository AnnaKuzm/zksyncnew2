ALTER TABLE blocks DROP COLUMN processable_onchain_ops;
