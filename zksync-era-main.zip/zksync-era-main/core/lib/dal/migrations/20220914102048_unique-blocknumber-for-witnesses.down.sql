ALTER TABLE witness_inputs DROP CONSTRAINT unique_witnesses;
