CREATE INDEX blocks_hash ON blocks USING hash (hash);
