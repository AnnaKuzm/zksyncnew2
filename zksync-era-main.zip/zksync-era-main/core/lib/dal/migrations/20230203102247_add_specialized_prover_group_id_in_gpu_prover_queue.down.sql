ALTER TABLE gpu_prover_queue
    DROP COLUMN IF EXISTS specialized_prover_group_id;
