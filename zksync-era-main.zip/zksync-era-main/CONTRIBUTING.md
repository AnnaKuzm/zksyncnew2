# Contribution Guidelines

Thank you for considering helping out with the source code! We are extremely grateful for any consideration of
contributions to this repository. However, at this time, we generally do not accept external contributions. This policy
will change in the future, so please check back regularly for updates.

For security issues, please contact us at [security@matterlabs.dev](mailto:security@matterlabs.dev).

Thank you for your support in accelerating the mass adoption of crypto for personal sovereignty!
